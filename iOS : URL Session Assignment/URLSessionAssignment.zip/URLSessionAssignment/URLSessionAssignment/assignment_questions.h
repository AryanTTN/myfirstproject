//
//  assignment_questions.h
//  URLSessionAssignment
//
//  Created by TTN on 12/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//
//------------------------------------------------------------------------------
//

// ASSIGNMENT QUESTIONS

//Q1.What is  URLSession?
//
//--> URLSession is the class responsible for making HTTP request and getting HTTP response.It is used to fetch and return data to your app, and download and upload files to webservices. You configure a session with a URLSessionConfiguration object. This configuration manages caching, cookies, connectivity and credentials.
//
//Q2.What are types of URLSessionConfiguration?
//
//--> URLSessionConfiguration is of three types :
//
//1) .default - This type of URLSession will save cache / cookie into disk, credentials are saved to keychain.
//
//2) .ephemeral - This type is similar to opening Incognito mode on Chrome or Private browsing on Firefox / Safari, cache / cookie / credential are stored in memory and will be gone and removed from the memory once the session is terminated.
//
//3) .background - This type of configuration allows the session to perform upload / download task in the background, meaning even if the app is suspended (in background), the upload / download task will still continue.
//
//
//Q3.What is  URLSessionTask? Explain Types of URLSessionTask?
//
//--> URLSessionTask is the class which is responsible for making request to the web API and uploading / downloading data.
//
//    There's 3 type of URLSessionTask :
//
//1) URLSessionDataTask - It is used for sending HTTP GET / POST / PUT / DELETE request, the data retrieved from response is saved into Memory in NSData / Data form
//2) URLSessionUploadTask - It is used for uploading file
//3) URLSessionDownloadTask - It is used for downloading file
