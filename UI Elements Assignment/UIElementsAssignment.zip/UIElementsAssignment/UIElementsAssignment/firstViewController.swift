//
//  firstViewController.swift
//  UIElementsAssignment
//
//  Created by TTN on 04/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class firstViewController: UIViewController {

    @IBOutlet weak var descriptionText: UITextView!
    @IBOutlet weak var nextbutton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        descriptionText.layer.borderColor = UIColor.systemPink.cgColor
        descriptionText.layer.borderWidth = 1.0
        
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
           navigationItem.title = "HOME"
       
       }

       @IBAction func nextButtonTapped() {

               let storyboard = UIStoryboard(name: "Main", bundle: nil)
               let secondVC = storyboard.instantiateViewController(withIdentifier: "secondViewController")

               navigationController?.pushViewController(secondVC, animated: true)
           }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
