//
//  ViewController.swift
//  AutoLayoutQ1
//
//  Created by TTN on 13/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//


// TASK 1 To make a text field and enter the the number according to which the view controller would open up
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var navigateButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func navigateButtonTapped() {
        
        let text = textField.text
        if (text == "1"){
            
            let vc = storyboard?.instantiateViewController(identifier: "firstViewController") as! firstViewController
            vc.navigationItem.largeTitleDisplayMode = .never
            navigationController?.pushViewController(vc, animated: true)
            
        } else if (text == "2"){
            
            let vc = storyboard?.instantiateViewController(identifier: "secondViewController") as! secondViewController
            vc.navigationItem.largeTitleDisplayMode = .never
            navigationController?.pushViewController(vc, animated: true)
            
        } else if (text == "3"){
            
            let vc = storyboard?.instantiateViewController(identifier: "thirdViewController") as! thirdViewController
            vc.navigationItem.largeTitleDisplayMode = .never
            navigationController?.pushViewController(vc, animated: true)
            
        } else if (text == "4"){
            
            let vc = storyboard?.instantiateViewController(identifier: "fourthViewController") as! fourthViewController
            vc.navigationItem.largeTitleDisplayMode = .never
            navigationController?.pushViewController(vc, animated: true)
            
        }
        
    }
    
}

