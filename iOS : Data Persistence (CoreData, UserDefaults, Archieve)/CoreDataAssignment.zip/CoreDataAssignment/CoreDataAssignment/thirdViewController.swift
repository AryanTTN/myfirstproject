//
//  thirdViewController.swift
//  CoreDataAssignment
//
//  Created by TTN on 12/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class thirdViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
    
    
    var myFavoritesList =  [String?]()
    var tempList = [Int]()
    
    @IBOutlet weak var favoritesListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        favoritesListTableView.dataSource = self
        favoritesListTableView.delegate = self
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingAfterNotified(notification:)),name: NSNotification.Name("This is notification Name"), object: nil)
    }
    
    @objc func doSomethingAfterNotified (notification: NSNotification) -> () {
        
        
        myFavoritesList = notification.object as! [String?]
       
        favoritesListTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(myFavoritesList.count)
        return myFavoritesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = favoritesListTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = myFavoritesList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 92.0
    }
    // Do any additional setup after loading the view.
}


/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destination.
 // Pass the selected object to the new view controller.
 }
 */


