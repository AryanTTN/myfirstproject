//
//  secondViewController.swift
//  NSNotificationCenterAssignment
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class secondViewController: UIViewController {

  
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Second VC"
        // Do any additional setup after loading the view.
    }
    // On clicking this button notification will be posted to both the VC's
    @IBAction func notificationButtonTapped(_ sender: Any) {
    
        NotificationCenter.default.post(name: Notification.Name("Notification Succesful"), object: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
