//
//  firstViewController.swift
//  NSNotificationCenterAssignment
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

// From this VC navigate to the third and the last one

class firstViewController: UIViewController {

    @IBOutlet weak var labelText : UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "First VC"
        
         // After reaching the last VC you'll find a button wich will be posting notification to this VC
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingOnGettingNotified),name: NSNotification.Name("Notification Succesful"), object: nil)
        
        // Do any additional setup after loading the view.
    }
    
    @objc func doSomethingOnGettingNotified () -> () {
        
        self.view.backgroundColor = #colorLiteral(red: 0.9686274529, green: 0.4271306626, blue: 0.9151251826, alpha: 1)
        labelText!.text = "Thanks for the Notification"
    }
    
    @IBAction func navigateButton2Tapped(_ sender: Any) {
      
        let vc: secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        
        deinit{
           
             NotificationCenter.default.removeObserver(self, name: NSNotification.Name("Notification Succesful"), object: nil)

         }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
