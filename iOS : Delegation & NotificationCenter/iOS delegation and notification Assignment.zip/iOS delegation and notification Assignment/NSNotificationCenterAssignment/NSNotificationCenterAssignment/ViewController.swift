//
//  ViewController.swift
//  NSNotificationCenterAssignment
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

// From this VC navigate to the second one

class ViewController: UIViewController {

    @IBOutlet weak var labelText : UILabel!
    
    override func viewDidLoad() {
            
        super.viewDidLoad()
        self.title = "Root VC"
        
        // After reaching the last VC you'll find a button wich will be posting notification to this VC
        NotificationCenter.default.addObserver(self,selector: #selector(doSomethingOnGettingNotified),name: NSNotification.Name("Notification Succesful"), object: nil)
            
            
        }
        
        @objc func doSomethingOnGettingNotified() {
  
            self.view.backgroundColor = #colorLiteral(red: 1, green: 0.9685441053, blue: 0.52856361, alpha: 1)
            labelText!.text = "Thanks for the Notification"
        }

    @IBAction func navigateButtonTapped(_ sender: Any) {
        let vc: firstViewController = self.storyboard?.instantiateViewController(withIdentifier: "firstViewController") as! firstViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    deinit{
          
            NotificationCenter.default.removeObserver(self, name: NSNotification.Name("Notification Succesful"), object: nil)

        }
    
    
    
}

