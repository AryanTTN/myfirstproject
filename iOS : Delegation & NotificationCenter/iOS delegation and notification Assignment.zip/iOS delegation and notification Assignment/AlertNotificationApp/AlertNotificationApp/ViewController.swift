//
//  ViewController.swift
//  AlertNotificationApp
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//



// After allowing the Notifications for your app close the app, run the app again, after the app opens immediately go to home and wait for 10 secs you'll receive the notification on your simulator.

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let notificationCenter = UNUserNotificationCenter.current()
             
        notificationCenter.requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in }
             
            
        let content = UNMutableNotificationContent()
        content.title = "You snooze, you lose this offer !!"
        content.body = "BUY 1 ,GET 2 FREE only till midnight"
        content.sound = UNNotificationSound.defaultCritical
        content.categoryIdentifier = "actionCategory"
        content.badge = 1
        
        
        let dismissAction = UNNotificationAction(identifier:"dismiss",
            title:"Dismiss this Notification",options:[])

        let category = UNNotificationCategory(identifier: "actionCategory",
             actions: [dismissAction],
            intentIdentifiers: [], options: [])

        UNUserNotificationCenter.current().setNotificationCategories([category])
             
        let date = Date().addingTimeInterval(10)
             
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute, .second], from: date)
             
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
             
        let uuidString = UUID().uuidString
             
        let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
             
             
        notificationCenter.add(request) { (error) in }
        
    }


}

