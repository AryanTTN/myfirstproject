//
//  firstViewController.swift
//  DelegationAssignment
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

protocol DataDelegate: class {
    
    func valuesToBeRecieved(_ data: [String: String?])
}

class firstViewController: UIViewController {

    weak var delegate: DataDelegate?
    
    @IBOutlet weak var userNameField: UITextField!
    
    @IBOutlet weak var motherNameField: UITextField!
    
    @IBOutlet weak var ageField: UITextField!
    
   var data: [String: String?] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func sendDataButtonTapped(_ sender: Any) {
        
        let data1: String? = userNameField!.text
        let data2: String? = motherNameField!.text
        let data3: String? = ageField!.text
        
        data = ["name":data1, "mother's name":data2, "age":data3]

        dismiss(animated: true) {
            self.delegate?.valuesToBeRecieved(self.data)
        }
        
    }

}
