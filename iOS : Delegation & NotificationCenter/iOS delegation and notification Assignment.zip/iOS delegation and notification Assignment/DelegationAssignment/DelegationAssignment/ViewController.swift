//
//  ViewController.swift
//  DelegationAssignment
//
//  Created by TTN on 05/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct dataModel {
    
    var userName: String?
    var motherName: String?
    var age: String?
    
    init(userName: String?, motherName: String?, age: String?) {
        self.userName = userName
        self.motherName = motherName
        self.age = age
    }
}

class ViewController: UIViewController {
    
    
    @IBOutlet weak var myTableView: UITableView!
    
    var recievedData: [String:String?] = [:]
    
    var dictDataValues: [dataModel] = []
    
    var myString: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        navigationItem.title = "User Information"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(insert))
        myTableView.register(MyTableViewCell.nib(), forCellReuseIdentifier: MyTableViewCell.identifier)
        myTableView.delegate = self
        myTableView.dataSource = self
    }
    
    @objc func insert() {
        let vc = storyboard?.instantiateViewController(identifier: "firstViewController") as! firstViewController
        self.present(vc, animated: true, completion: nil)
        vc.delegate = self
        
    }
    
    
}

extension ViewController: DataDelegate , UITableViewDelegate, UITableViewDataSource {
    
    func valuesToBeRecieved(_ data: [String : String?]) {
        
        let model = dataModel(userName: data["name"] ?? "", motherName: data["mother's name"] ?? "", age: data["age"] ?? "")
        dictDataValues.append(model)
        myTableView.reloadData()
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return dictDataValues.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = myTableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath) as! MyTableViewCell
        
        cell.getDataFunction(element: dictDataValues[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 92.0
    }
    
}
