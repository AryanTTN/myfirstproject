//
//  MyTableViewCell.swift
//  DelegationAssignment
//
//  Created by TTN on 06/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var motherNameLabel: UILabel!
    
    @IBOutlet weak var ageLabel: UILabel!
    
    static let identifier = "MyTableViewCell"
               
           static func nib() -> UINib{
               return UINib(nibName: "MyTableViewCell", bundle: nil)
           }
       

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func getDataFunction(element: dataModel){

    userNameLabel!.text = element.userName
    motherNameLabel!.text = element.motherName
    ageLabel!.text = element.age
    
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
