//
//  ButtonSwiftUIView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ButtonSwiftUIView: View {
    var body: some View {
        Button(action: {
                  }, label: {
                      Text("CLICK ME !!")
                        .foregroundColor(.black)
                        .font(.custom("zapfino", size: 25))
                  })
                      .padding(.all, 20)
                      .background(Color.pink)
                      .cornerRadius(25)
        }
    }


struct ButtonSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonSwiftUIView()
    }
}
