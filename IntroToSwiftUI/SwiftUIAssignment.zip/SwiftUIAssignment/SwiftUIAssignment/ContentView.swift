//
//  ContentView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
           return NavigationView{
               List{
                Section(header: Text("BASIC CONTROLS"))
                {
                   NavigationLink(destination: ImageSwiftUIView()){
                       Text("IMAGE")
                   }
                   NavigationLink(destination: TextSwiftUIView()){
                       Text("SOME TEXT")
                   }
                   NavigationLink(destination: VerticalStackSwiftUI()){
                       Text("VERTICAL STACK VIEW EXAMPLE")
                   }
                   NavigationLink(destination: HorizontalStackSwiftUIView()){
                        Text("HORIZONTAL STACK VIEW EXAMPLE")
                   }
                   NavigationLink(destination: ButtonSwiftUIView()){
                       Text("BUTTON")
                   }
                   NavigationLink(destination: PickerSwiftUIView()){
                        Text("PICKER")
                   }
                } .foregroundColor(.blue)
                    .font(.system(size: 20))
               }
           }
       }
}
  

struct MultipleView_Previews: PreviewProvider {
    static var previews: some View {
        Group{
                    ContentView()
                    .previewDevice(PreviewDevice(rawValue: "iPhone 11"))
                    .previewDisplayName("iphone 11")
            
                   ContentView()
                   .previewDevice(PreviewDevice(rawValue: "iPhone 11 Pro Max"))
                   .previewDisplayName("iPhone 11 Pro Max")

                    ContentView()
                    .previewDevice(PreviewDevice(rawValue: "iPhone 11 pro"))
                    .previewDisplayName("iphone 11 pro")
            

                    ContentView()
                    .previewDevice(PreviewDevice(rawValue: "iPhone 8 plus"))
                    .previewDisplayName("iphone 8 plus")
            

                    ContentView()
                    .previewDevice(PreviewDevice(rawValue: "iPhone 8"))
                    .previewDisplayName("iphone 8")
            
            
        }
    }
}
