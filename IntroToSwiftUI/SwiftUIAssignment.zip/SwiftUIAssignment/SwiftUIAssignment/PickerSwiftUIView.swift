//
//  PickerSwiftUIView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct PickerSwiftUIView: View {
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        return formatter
    }
    
    @State private var birthDate = Date()
    
    var body: some View {
        
        VStack {
            DatePicker(selection: $birthDate, displayedComponents: .date) {
                Text("User selected, \(birthDate, formatter: dateFormatter)")
            }
        } .background(Color.init(red: 0.80, green: 0.50, blue: 0.80))
        .cornerRadius(20)
    }
}

struct PickerSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        PickerSwiftUIView()
    }
}
