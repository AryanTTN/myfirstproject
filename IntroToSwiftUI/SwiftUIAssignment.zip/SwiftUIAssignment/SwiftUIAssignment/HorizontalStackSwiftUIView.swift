//
//  HorizontalStackSwiftUIView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct HorizontalStackSwiftUIView: View {
    var body: some View {
       HStack(alignment: .top, spacing: 20.0) {
           Text("Welcome To TTN --> ")
               .padding(.top, 30)
               .lineLimit(nil)
               .foregroundColor(.green)
               .font(.custom("zapfino", size: 20))

           Image("ttn")
            .shadow(color:.green, radius: 0.50, x: 0.6, y: 0.6)
               
       }
    }
}

struct HorizontalStackSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalStackSwiftUIView()
    }
}
