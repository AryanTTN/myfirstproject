//
//  TextSwiftUIView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct TextSwiftUIView: View {
    var body: some View {
        Text("Welcome To TTN")
        .foregroundColor(.orange)
        .font(.custom("zapfino", size: 25))
        .bold()
        .padding(.all,5)
        
    }
}

struct TextSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        TextSwiftUIView()
    }
}
