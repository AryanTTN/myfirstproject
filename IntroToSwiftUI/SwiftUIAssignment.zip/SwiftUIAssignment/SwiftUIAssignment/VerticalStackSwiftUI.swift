//
//  VerticalStackSwiftUI.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct VerticalStackSwiftUI: View {
    var body: some View {
        VStack{
            Text("Welcome To iOS Bootcamp 2021")
                .foregroundColor(.purple)
                .font(.custom("zapfino", size: 18))
            Image("Icon")
                .frame(width: 200, height: 220)
            
            Text("Hope you'll enjoy the Work environment!!")
                .font(.custom("zapfino", size: 18))
                .multilineTextAlignment(.center)
                .foregroundColor(.accentColor)
        }
    }
}

struct VerticalStackSwiftUI_Previews: PreviewProvider {
    static var previews: some View {
        VerticalStackSwiftUI()
    }
}
