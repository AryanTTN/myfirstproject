//
//  ImageSwiftUIView.swift
//  SwiftUIAssignment
//
//  Created by TTN on 09/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import SwiftUI

struct ImageSwiftUIView: View {
    var body: some View {
        Image("Icon")
        .resizable()
        .accentColor(.purple)
        .cornerRadius(50)
        .frame(width: 300, height: 300)

    }
}

struct ImageSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        ImageSwiftUIView()
    }
}
