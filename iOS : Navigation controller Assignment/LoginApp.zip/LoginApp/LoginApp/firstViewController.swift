//
//  firstViewController.swift
//  LoginApp
//
//  Created by TTN on 24/02/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class firstViewController: UIViewController {
    
    var nameLabel : String!
    @IBOutlet weak var moveForwardButton : UIButton!
    @IBOutlet weak var dismissButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barTintColor = UIColor.systemOrange
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    @IBAction func moveForwardButtonTapped(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "thirdViewController")
        //        self.present(vc, animated: true)
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func dismissButtonTapped() {
        self.dismiss(animated: true, completion: nil)
    }
    
}
/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destination.
 // Pass the selected object to the new view controller.
 }
 */


