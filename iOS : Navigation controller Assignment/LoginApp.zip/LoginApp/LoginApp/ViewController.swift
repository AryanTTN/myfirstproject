//
//  ViewController.swift
//  LoginApp
//
//  Created by TTN on 16/02/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var presentLoginButton: UIButton!
    
    @IBOutlet weak var pushLoginButton : UIButton!
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var dataPassingButton: UIButton!
    
    var passText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        NotificationCenter.default.post(name: Notification.Name("text"), object: textField.text)
              
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    
    
    @IBAction func presentLoginButtonTapped() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "firstViewController")
            as! firstViewController
        let navController = UINavigationController.init(rootViewController: vc)
        vc.nameLabel = "SignIn to first view controller"
        
        // self.present(vc, animated: true)
        self.present(navController, animated: true, completion: nil)
        //navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func pushLoginButtonTapped(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc2 = storyboard.instantiateViewController(withIdentifier: "secondViewController")
            as! secondViewController
        vc2.subNameLabel = "SignIn to second view controller"
        //        self.present(vc, animated: true)
        navigationController?.pushViewController(vc2, animated: true)
        
    }
    
    @IBAction func didTapdataPassingButton(){
      
        passText = textField.text!
        performSegue(withIdentifier: "passSegue", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! fifthViewController
        vc.finalText = self.passText
    }
    
    
}

//extension ViewController : UITextFieldDelegate{
//
//}
