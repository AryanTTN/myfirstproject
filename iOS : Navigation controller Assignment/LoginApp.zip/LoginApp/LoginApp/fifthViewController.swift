//
//  fifthViewController.swift
//  LoginApp
//
//  Created by TTN on 03/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class fifthViewController: UIViewController {
    
    @IBOutlet weak var popToAnyButton : UIButton!
    
    @IBOutlet weak var dismissButton: UIButton!
    
    @IBOutlet weak var label: UILabel!
    
    var finalText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        label.text = finalText
        
        navigationController?.navigationBar.barTintColor = UIColor.systemGreen
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.tintColor = UIColor.purple
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .done,
            target: nil,
            action: nil
        )
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        navigationItem.title = "Fifth Screen"
    }
    
    @IBAction func popToAnyButtonTapped(){
        if let vc = navigationController?.viewControllers.filter({$0 is secondViewController}).first as? secondViewController {
            self.navigationController!.popToViewController(vc, animated: true)
        }
    }
    
    @IBAction func dismissButtonTapped() {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
