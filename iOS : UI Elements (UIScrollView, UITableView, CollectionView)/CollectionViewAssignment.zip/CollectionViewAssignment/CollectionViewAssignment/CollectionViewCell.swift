//
//  CollectionViewCell.swift
//  CollectionViewAssignment
//
//  Created by TTN on 27/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var myLabel : UILabel!
    @IBOutlet weak var myImageView : UIImageView!
    
    static let identifier = "CollectionViewCell"
    
    static func nib() -> UINib {
        return UINib(nibName: "CollectionViewCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    public func configure(with model : rowModel){
        myLabel.text = model.text
        myImageView.image = UIImage(named: model.imageName)
    }
    
}
