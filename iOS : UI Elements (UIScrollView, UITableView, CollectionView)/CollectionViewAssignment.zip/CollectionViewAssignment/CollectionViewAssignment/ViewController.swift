//
//  ViewController.swift
//  CollectionViewAssignment
//
//  Created by TTN on 27/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var myTable : UITableView!
    
    var models = [rowModel]()    //array of rowModel objects
    var categories = ["Horror","Action", "Drama", "Science Fiction", "Kids", "Thriller","Crime"]      
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        models.append(rowModel(text: "Annabelle Creation", imageName: "annabelle"))
        models.append(rowModel(text: "The Convent", imageName: "convent"))
        models.append(rowModel(text: "Hereditary", imageName: "hereditary"))
        models.append(rowModel(text: "It Ends", imageName: "it"))
        models.append(rowModel(text: "Pet Semetary", imageName: "pet"))
        models.append(rowModel(text: "The Reckoning", imageName: "reckoning"))
        models.append(rowModel(text: "Us", imageName: "us"))
        models.append(rowModel(text: "The Ruins", imageName: "ruins"))
        models.append(rowModel(text: "Slapface", imageName: "slapface"))
        //         models.append(Model(text: "1", imageName: "a1"))
        //         models.append(Model(text: "2", imageName: "a2"))
        //         models.append(Model(text: "3", imageName: "a3"))
        //         models.append(Model(text: "4", imageName: "a4"))
        
        
        myTable.register(TableViewCell.nib(), forCellReuseIdentifier: TableViewCell.identifier)
        myTable.delegate = self
        myTable.dataSource = self
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return categories[section]
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTable.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        cell.rowConfigure(with: models)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0
    }
    
}

struct rowModel{
    let text : String
    let imageName : String
    
    init(text:String,imageName:String) {
        self.text = text
        self.imageName = imageName
    }
    
}
