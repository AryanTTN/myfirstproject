//
//  firstViewController.swift
//  ViewsAssignment
//
//  Created by TTN on 05/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//



//  TASK 2 AND TASK 3 IMPLEMENTED

import UIKit

class firstViewController: UIViewController {

    @IBOutlet weak var icon1: UIImageView!
    


    override func viewDidLoad() {
        super.viewDidLoad()
        icon1?.layer.cornerRadius = (icon1?.frame.size.width ?? 0.0) / 2
        icon1?.clipsToBounds = true
        icon1?.layer.borderWidth = 3.0
        icon1?.layer.borderColor = UIColor.black.cgColor
        
    }

   
   

}
