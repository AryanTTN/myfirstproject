//
//  ViewController.swift
//  DesignPatternAssignment
//
//  Created by TTN on 30/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct personDetailsModel {
    
    var name: String
    var email: String
    var address: String
    var zipCode: String
}

var modelObj = [personDetailsModel(name: "Ammy", email: "ammy@gmail.com", address: "london", zipCode: "1557"),
    personDetailsModel(name: "Lia", email: "lia@rediff.com", address: "New York City", zipCode: "6654"),
    personDetailsModel(name: "Alisha", email: "alisha@gmail.com", address: "Burmingham", zipCode: "1457"),
    personDetailsModel(name: "Rob", email: "rob@yahoo.com", address: "santa clara", zipCode: "3221"),
    personDetailsModel(name: "Claudia", email: "claudia@gmail.com", address: "texas", zipCode: "6607"),
    personDetailsModel(name: "Max", email: "max@rediff.com", address: "malaysia", zipCode: "5476"),
    personDetailsModel(name: "Nadia", email: "nadia@gmail.com", address: "Ukraine", zipCode: "9880"),
    personDetailsModel(name: "Jimzhu", email: "jimzhu@gmail.com", address: "Wuhan", zipCode: "0081"),
    personDetailsModel(name: "Lakshay", email: "lakshay@gmail.com", address: "Lucknow", zipCode: "2824"),
    personDetailsModel(name: "Sally", email: "sally@yahoo.com", address: "Sydney", zipCode: "7137")]

class  personDetails {
    
    static let shared = personDetails()

    private init(){}
    
    var personDetailsObj : [personDetailsModel] = modelObj
}


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func goToFirstVC(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "firstViewController") as! firstViewController
       vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func goToSecondVC(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "secondViewController") as! secondViewController
//      vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func goToThirdVC(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "thirdViewController") as! thirdViewController
       // vc.navigationItem.largeTitleDisplayMode = .never
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

