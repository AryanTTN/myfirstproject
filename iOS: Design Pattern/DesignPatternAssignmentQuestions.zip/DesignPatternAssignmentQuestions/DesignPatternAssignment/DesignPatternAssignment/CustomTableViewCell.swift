//
//  CustomTableViewCell.swift
//  DesignPatternAssignment
//
//  Created by TTN on 31/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var tempLabel: UILabel!
    
    static let identifier = "CustomTableViewCell"
             
         static func nib() -> UINib{
             
             return UINib(nibName: "CustomTableViewCell", bundle: nil)
             
         }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureFunction1(element: personDetailsModel){
              nameLabel.text = element.name
              tempLabel.text = element.email
          }
       
           func configureFunction2(element: personDetailsModel){
               nameLabel.text = element.name
               tempLabel.text = element.address
           }
       
           func configureFunction3(element: personDetailsModel){
               nameLabel.text = element.name
            tempLabel.text = element.zipCode
           }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
