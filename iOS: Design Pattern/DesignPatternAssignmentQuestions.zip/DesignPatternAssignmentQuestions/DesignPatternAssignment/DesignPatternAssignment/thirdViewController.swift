//
//  thirdViewController.swift
//  DesignPatternAssignment
//
//  Created by TTN on 31/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class thirdViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

   
    @IBOutlet weak var tableView: UITableView!
    

    
        var personDetailsObj3 = personDetails.shared.personDetailsObj
    
       override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           tableView.register(CustomTableViewCell.nib(), forCellReuseIdentifier: CustomTableViewCell.identifier)
           tableView.delegate = self
           tableView.dataSource = self
       }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
           115.0
       }
       func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return personDetailsObj3.count
         }
         
         func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

           
           let cell = tableView.dequeueReusableCell(withIdentifier: CustomTableViewCell.identifier, for: indexPath) as! CustomTableViewCell
           
           cell.configureFunction3(element: personDetailsObj3[indexPath.row])
           return cell
         }

    
}
