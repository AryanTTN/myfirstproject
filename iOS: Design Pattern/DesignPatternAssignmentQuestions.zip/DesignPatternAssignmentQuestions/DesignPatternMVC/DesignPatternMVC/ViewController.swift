//
//  ViewController.swift
//  DesignPatternMVC
//
//  Created by TTN on 31/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct personDetailsModel {
    
    var name: String
    var email: String
    var address: String
    var zipCode: String
}

var modelObj = [personDetailsModel(name: "Ammy", email: "ammy@gmail.com", address: "london", zipCode: "1557"),
    personDetailsModel(name: "Lia", email: "lia@rediff.com", address: "New York City", zipCode: "6654"),
    personDetailsModel(name: "Alisha", email: "alisha@gmail.com", address: "Burmingham", zipCode: "1457"),
    personDetailsModel(name: "Rob", email: "rob@yahoo.com", address: "santa clara", zipCode: "3221"),
    personDetailsModel(name: "Claudia", email: "claudia@gmail.com", address: "texas", zipCode: "6607"),
    personDetailsModel(name: "Max", email: "max@rediff.com", address: "malaysia", zipCode: "5476"),
    personDetailsModel(name: "Nadia", email: "nadia@gmail.com", address: "Ukraine", zipCode: "9880"),
    personDetailsModel(name: "Jimzhu", email: "jimzhu@gmail.com", address: "Wuhan", zipCode: "0081"),
    personDetailsModel(name: "Lakshay", email: "lakshay@gmail.com", address: "Lucknow", zipCode: "2824"),
    personDetailsModel(name: "Sally", email: "sally@yahoo.com", address: "Sydney", zipCode: "7137")]


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
          super.viewDidLoad()
          // Do any additional setup after loading the view.
          tableView.register(TableViewCell.nib(), forCellReuseIdentifier: TableViewCell.identifier)
          tableView.delegate = self
          tableView.dataSource = self
      }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modelObj.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: TableViewCell.identifier, for: indexPath) as! TableViewCell
        
        cell.configureFunction(element: modelObj[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 115.0
    }
    

  

}

