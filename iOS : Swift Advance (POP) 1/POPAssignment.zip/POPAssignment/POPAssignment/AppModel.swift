//
//  AppModel.swift
//  POPAssignment
//
//  Created by TTN on 01/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import Foundation

struct Employee {
    var email: String
    var phoneNumber: String
    var employeeId: String
    var fName: String
    var lName: String
    var imageUser: String
    var userRole: String
    var joiningDate: String //extension for getting date
    var id: String
    var address: String
    
    init(email: String, phoneNumber: String, employeeId: String, fName: String, lName: String, imageUser: String, userRole: String, joiningDate: Date, id: String, address: String) {
        self.email = email
        self.phoneNumber = phoneNumber
        self.employeeId = employeeId
        self.fName = fName
        self.lName = lName
        self.imageUser = imageUser
        self.userRole = userRole
        self.joiningDate = joiningDate.currentDate
        self.id = id
        self.address = address
    }
}

struct Client {
    var email: String
    var name: String
    var phoneNumber: String
    var imageUser: String
    var id: String
    var address: String
    
    init(email: String, phoneNumber: String, name: String, imageUser: String, id: String, address: String) {
        self.email = email
        self.name = name
        self.phoneNumber = phoneNumber
        self.imageUser = imageUser
        self.id = id
        self.address = address
    }
}

extension Date {
    var currentDate: String {
        let joiningDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd.MM.yyyy"
        let result = formatter.string(from: joiningDate)
        return result
    }
}

class AppModel: NSObject {

    var employees: [Employee] =
        [Employee.init(email: "aryan@tothenew.com", phoneNumber: "9936548346", employeeId: "1", fName: "Aryan", lName: "Sethi", imageUser: "harry", userRole: "Trainee",joiningDate: Date() , id: "1", address: "Agra"),
        Employee.init(email: "rahul@tothenew.com", phoneNumber: "9336554664", employeeId: "2", fName: "Rahul", lName: "Sharma", imageUser: "ron", userRole: "Trainee",joiningDate: Date(), id: "2", address: "Haridwar"),
         Employee.init(email: "kavya@tothenew.com", phoneNumber: "8734512540", employeeId: "3", fName: "Kavya", lName: "Casshyap", imageUser: "hermoine", userRole: "Trainee",joiningDate: Date() , id: "3", address: "Vasant Kunj"),
         Employee.init(email: "harsh@tothenew.com", phoneNumber: "7823675498", employeeId: "4", fName: "Harsh", lName: "Agarwal", imageUser: "neville", userRole: "Trainee",joiningDate: Date(), id: "4", address: "Delhi"),
         Employee.init(email: "vijender@tothenew.com", phoneNumber: "9122545634", employeeId: "5", fName: "Vijender", lName: "Negi", imageUser: "fred", userRole: "Trainee",joiningDate: Date(), id: "5", address: "Delhi")]

    var clients: [Client] =
        [Client.init(email: "kabir@gmail.com", phoneNumber: "8872039485", name: "Kabir", imageUser: "panda", id: "1", address: "Shimla"),
         Client.init(email: "anushka@yahoo.com", phoneNumber: "8922314538", name: "Anushka", imageUser: "tigress", id: "2", address: "Pune"),
         Client.init(email: "isha@rediff.com", phoneNumber: "7071236735", name: "Isha", imageUser: "bird", id: "3", address: "Surat"),
         Client.init(email: "Ritik@yahoo.com", phoneNumber: "7765234124", name: "Ritik", imageUser: "guru", id: "4", address: "Hyderabad"),
         Client.init(email: "karan@outlook.com", phoneNumber: "9969645746", name: "Karan", imageUser: "monkey1", id: "5", address: "Ahemdabad")
    ]
}
