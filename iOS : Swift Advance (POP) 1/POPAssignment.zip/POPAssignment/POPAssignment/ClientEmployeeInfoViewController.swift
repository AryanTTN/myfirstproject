//
//  ClientEmployeeInfoViewController.swift
//  POPAssignment
//
//  Created by TTN on 01/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

struct generalInfo {
    var name: String
    var id: String
    var email: String
    var phoneNumber: String
    
    init(name: String, id: String, email: String, phoneNumber: String) {
        self.name = name
        self.id = id
        self.email = email
        self.phoneNumber = phoneNumber
    }
}

class ClientEmployeeInfoViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{

    var userName: String = ""
    var email: String = ""
    var phoneNumber: String = ""
    var id: String = ""
    var imageOfUser: String = ""
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var myTableView: UITableView!
    
    var model: AppModel = AppModel()
    var employeeArray: [Employee] {
        return model.employees
    }
    var clientArray: [Client] {
        return model.clients
    }
    var generalArray: [generalInfo] = []
    //image
    
    func convertData() {
        for idx in 0..<employeeArray.count {
            generalArray.append(generalInfo(name: employeeArray[idx].fName, id: employeeArray[idx].employeeId, email: employeeArray[idx].email, phoneNumber: employeeArray[idx].phoneNumber))
        }
        for idx in 0..<clientArray.count {
            generalArray.append(generalInfo(name: clientArray[idx].name, id: clientArray[idx].id, email: clientArray[idx].email, phoneNumber: clientArray[idx].phoneNumber))
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        convertData()
        
        let nib = UINib(nibName: "MyTableViewCell", bundle: nil)
        
        myTableView.register(nib, forCellReuseIdentifier: "MyTableViewCell")
        
        myTableView.delegate = self
        myTableView.dataSource = self
        myTableView.reloadData()
        myTableView.layoutIfNeeded()
        idLabel.text = id
        nameLabel.text = userName
        emailLabel.text = email
        contactLabel.text = phoneNumber
     
        let image = UIImage(named: imageOfUser)
        userImageView.image = image
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        myTableView.heightAnchor.constraint(equalToConstant:
        myTableView.contentSize.height).isActive = true
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return generalArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: MyTableViewCell.identifier, for: indexPath) as! MyTableViewCell
        cell.transferData(element: generalArray[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 101.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.showToast(message: "Greetings to \(generalArray[indexPath.row].name) from \(userName)", font: .systemFont(ofSize: 15.0))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
