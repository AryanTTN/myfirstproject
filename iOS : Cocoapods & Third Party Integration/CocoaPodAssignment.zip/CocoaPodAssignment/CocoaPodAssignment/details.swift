//
//  details.swift
//  CocoaPodAssignment
//
//  Created by TTN on 29/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//
import Foundation

struct details:Decodable {
    
    let id: String
    let author: String
    let width: Int
    let height: Int
    let download_url: String
}

