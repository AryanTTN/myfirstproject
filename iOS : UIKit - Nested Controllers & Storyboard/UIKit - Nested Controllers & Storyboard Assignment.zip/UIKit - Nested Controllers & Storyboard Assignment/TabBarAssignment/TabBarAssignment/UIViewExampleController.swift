//
//  secondViewController.swift
//  TabBarAssignment
//
//  Created by TTN on 16/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class UIViewExampleController: UIViewController {

    @IBOutlet weak var newView : UIView!
    @IBOutlet weak var label : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        
        label.text = "This day is beautiful"
        label.textAlignment = .center
        label.font = UIFont(name: "zapfino", size: 20)
        label.numberOfLines = 0
        newView.backgroundColor = #colorLiteral(red: 0.812652461, green: 0.6862261294, blue: 1, alpha: 1)
        newView.layer.shadowColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)
        newView.layer.cornerRadius = 20.0
        newView.layer.shadowOpacity = 0.8
        newView.layer.shadowRadius = 5.0
        newView.layer.shadowOffset = CGSize(width: -20, height: -20)
        newView.layer.masksToBounds = true
        newView.clipsToBounds = false
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
