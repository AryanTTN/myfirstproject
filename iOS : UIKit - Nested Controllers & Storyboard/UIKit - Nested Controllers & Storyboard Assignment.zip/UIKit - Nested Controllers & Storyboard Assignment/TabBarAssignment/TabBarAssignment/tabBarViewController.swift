//
//  tabBarViewController.swift
//  TabBarAssignment
//
//  Created by TTN on 17/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class tabBarViewController: UIViewController {

    private let enterButton: UIButton = {
        let  button = UIButton(frame: CGRect(x: 0, y: 0, width: 400, height: 80))
        button.setTitle("MOVE TO TAB BAR", for: .normal)
        button.titleLabel?.font = UIFont(name: "zapfino", size: 20)
        button.titleLabel?.numberOfLines = 0
        button.backgroundColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        button.layer.cornerRadius = 15.0
        button.setTitleColor(#colorLiteral(red: 0.09019608051, green: 0, blue: 0.3019607961, alpha: 1), for: .normal)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0.812652461, green: 0.6862261294, blue: 1, alpha: 1)
        view.addSubview(enterButton)
        enterButton.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        enterButton.center = view.center
    }
    
    @objc func didTapButton() {
        //Creating and presenting tab bar controller
        let tabBarVC = UITabBarController()
        
        let vc1 = UINavigationController(rootViewController: newFirstViewController())
        let vc2 = UINavigationController(rootViewController: newSecondViewController())
        let vc3 = UINavigationController(rootViewController: newThirdViewController())
        let vc4 = UINavigationController(rootViewController: newFourthViewController())
       
        vc1.title = "Home"
        vc2.title = "Gallery"
        vc3.title = "Featured"
        vc4.title = "Settings"
        
        tabBarVC.setViewControllers([vc1, vc2, vc3, vc4], animated: true)
        
        guard let tabBarItems = tabBarVC.tabBar.items else {
            return
        }
        
        let itemImages = ["house", "camera.fill", "star", "gear"]
        
        for i in 0..<tabBarItems.count {
            tabBarItems[i].image = UIImage(systemName: itemImages[i])
        }
        
        tabBarVC.modalPresentationStyle = .automatic
        present(tabBarVC, animated: true)
    }

}

class newFirstViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0, green: 1, blue: 0.6054910253, alpha: 1)
        title = "Home"
    }
}

class newSecondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0.9366665998, green: 1, blue: 0.08663718575, alpha: 1)
        title = "Gallery"
    }
}

class newThirdViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0.8235294223, green: 0.3640480696, blue: 0.7813884588, alpha: 1)
        title = "Featured"
    }
}

class newFourthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = #colorLiteral(red: 0.812652461, green: 0.6862261294, blue: 1, alpha: 1)
        title = "Settings"
    }
}






