//
//  PagingViewController.swift
//  PagingApp
//
//  Created by TTN on 17/03/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class PagingViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource {
    
    weak var pagingDelegate: PagingViewController?
    
    private(set) lazy var newViewControllers: [UIViewController] = {
        // The view controllers will be shown in this order
        return [self.newColoredViewController(color: "Purple"),
                self.newColoredViewController(color : "Pink"),
                self.newColoredViewController(color :"Green")]
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSource = self
        delegate = self
        
        if let initialViewController = newViewControllers.first {
            setViewControllers([initialViewController], direction: .forward, animated: true, completion: nil)
        }
        // Do any additional setup after loading the view.
    }
    
    private func newColoredViewController(color: String) -> UIViewController {
        return UIStoryboard(name: "Main", bundle: nil) .
            instantiateViewController(withIdentifier: "\(color)ViewController")
    }
    
    
    
    
}
extension PagingViewController {
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = newViewControllers.firstIndex(of: viewController) else { return nil }
        
        let previousIndex = viewControllerIndex - 1
        
        guard previousIndex >= 0          else { return newViewControllers.last }
        
        guard newViewControllers.count > previousIndex else { return nil        }
        
        return newViewControllers[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController,
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = newViewControllers.firstIndex(of: viewController) else { return nil }
        
        let nextIndex = viewControllerIndex + 1
        
        guard nextIndex < newViewControllers.count else { return newViewControllers.first }
        
        guard newViewControllers.count > nextIndex else { return nil         }
        
        return newViewControllers[nextIndex]
    }
    
}
