//
//  ViewController.swift
//  ClientServerAssignment
//
//  Created by TTN on 14/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addNavBarImage()
    
    }
    
    @IBAction func downloadImagesButtonTapped(_ sender: Any) {
        
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
        vc.authorButtonTappedIsTapped = false
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    @IBAction func authorButtonTapped(_ sender: Any) {
        
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
        vc.authorButtonTappedIsTapped = true
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    // adding custom nav bar logo
    func addNavBarImage() {
        let navController = navigationController!
        let image = UIImage(named: "logo") //Your logo url here
        let imageView = UIImageView(image: image)
        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height - 2
        imageView.frame = CGRect(x: 0, y: 0, width: bannerWidth, height: bannerHeight)
        imageView.contentMode = .scaleAspectFit
        navigationItem.titleView = imageView
    }
    
}

