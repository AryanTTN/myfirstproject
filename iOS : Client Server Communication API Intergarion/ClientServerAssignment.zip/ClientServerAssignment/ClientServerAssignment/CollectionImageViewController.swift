//
//  CollectionImageViewController.swift
//  ClientServerAssignment
//
//  Created by TTN on 18/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit

// setting the view of the image coming from the api
extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFill) {
        contentMode = mode
        print("URL is here \(url)")
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
}


class CollectionImageViewController: UIViewController {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var idLabel: UILabel!
    
    @IBOutlet weak var filenameLabel: UILabel!
    
    @IBOutlet weak var widthLabel: UILabel!
    
    @IBOutlet weak var heightLabel: UILabel!
    
    @IBOutlet weak var formatLabel: UILabel!
    
    @IBOutlet weak var authorLabel: UILabel!
    
    open var gotDetails: details?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addNavBarImage()
        idLabel.text = "\((gotDetails?.id) ?? 0)"
        authorLabel.text = gotDetails?.author
        widthLabel.text = "\((gotDetails?.width) ?? 0)"
        heightLabel.text = "\((gotDetails?.height) ?? 0)"
        filenameLabel.text = gotDetails?.filename
        formatLabel.text = gotDetails?.format
        
        let id : String = "\((gotDetails?.id) ?? 0)"
        let urlString = "https://picsum.photos/200/300?image=" + id
        let url = URL(string: urlString)!
        imageView.downloadedFrom(url: url)
    }
    //button Action to download images to phone library
    @IBAction func downloadImageButtonTapped(_ sender: Any) {
        
        let id : String = "\((gotDetails?.id) ?? 0)"
        let urlString = "https://picsum.photos/200/300?image=" + id
        let url = URL(string: urlString)!
        let data = try? Data(contentsOf: url)
        
        UIImageWriteToSavedPhotosAlbum(UIImage(data: data!)!, nil, nil, nil)
        print("Image Downloaded to Photos")
    }
    
    func addNavBarImage() {
        let navController = navigationController!
        let image = UIImage(named: "logo") //Your logo url here
        let imageView = UIImageView(image: image)
        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height - 2
        imageView.frame = CGRect(x: 0, y: 0, width: bannerWidth, height: bannerHeight)
        imageView.contentMode = .scaleAspectFit
        navigationItem.titleView = imageView
    }
}
