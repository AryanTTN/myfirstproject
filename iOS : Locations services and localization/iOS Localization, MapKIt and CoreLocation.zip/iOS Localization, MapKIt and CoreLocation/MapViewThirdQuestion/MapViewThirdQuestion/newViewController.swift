//
//  newViewController.swift
//  MapViewThirdQuestion
//
//  Created by TTN on 07/04/21.
//  Copyright © 2021 TTN. All rights reserved.
//

import UIKit
import MapKit

class newViewController: UIViewController, CLLocationManagerDelegate {
    
    //@IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imageView: UIImageView!
    
     private let locationManager = CLLocationManager()
    var USACoordinates: String = "United States"
    var currentCountryName:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func checkLocationAuthorization() {
           switch CLLocationManager.authorizationStatus() {
           case .authorizedWhenInUse:
               locationManager.startUpdatingLocation()
               
               break
           case .denied:
               // Show alert
               break
           case .notDetermined:
               locationManager.requestWhenInUseAuthorization()
           case .restricted:
               // Show alert
               break
           case .authorizedAlways:
               break
           @unknown default:
            break
        }
       }
    
      func fetchImage() {
          let imageURL: URL = URL(string: "http://www.newsonair.com/writereaddata/News_Pictures/NAT/2018/Nov/NPIC-201811142185.jpg")!
       
          (URLSession(configuration: URLSessionConfiguration.default)).dataTask(with: imageURL, completionHandler: { (imageData, response, error) in
       
              if let data = imageData {
                  print("Did download image data")
               
                  DispatchQueue.main.async {
                      self.imageView.image = UIImage(data: data)
                  }
              }
          }).resume()
      }
    
    
    @IBAction func showImageButtonTapped(_ sender: Any) {
        
        let status: CLAuthorizationStatus = CLLocationManager.authorizationStatus()
        if (status == .authorizedWhenInUse || status == .authorizedAlways)  && USACoordinates == currentCountryName {
            fetchImage()
        } else {
            showAlert()
        }
    }
    
    func showAlert() {
        let ac = UIAlertController(title: "This feature is not supported  in your country", message: nil, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
        present(ac, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
